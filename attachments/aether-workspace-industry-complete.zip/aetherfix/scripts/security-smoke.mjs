#!/usr/bin/env node
import assert from "node:assert/strict";
import { test } from "node:test";
import { readFileSync } from "node:fs";

const client = readFileSync(new URL("../src/lib/auth/client.ts", import.meta.url), "utf8");
const popup = readFileSync(new URL("../src/lib/auth/popup.server.ts", import.meta.url), "utf8");
const highlight = readFileSync(new URL("../src/lib/aether/highlight.ts", import.meta.url), "utf8");
const rtc = readFileSync(new URL("../src/lib/multiplayer/signaling.server.ts", import.meta.url), "utf8");

test("auth callbacks are normalized to same-origin paths", () => {
  assert.match(client, /safeCallbackPath/);
  assert.doesNotMatch(client, /window\.location\.href\s*=\s*callbackURL/);
});

test("popup provider is allowlisted and opener is authenticated", () => {
  assert.match(popup, /GROK_PROVIDERS\.some/);
  assert.match(client, /event\.source !== popup/);
});

test("highlighting does not directly trust raw HTML", () => {
  assert.match(highlight, /&amp;/);
  assert.match(highlight, /&lt;/);
  assert.match(highlight, /&gt;/);
});

test("RTC signaling has strict schema and bounded traffic", () => {
  assert.match(rtc, /MAX_SIGNAL_BYTES/);
  assert.match(rtc, /MAX_ROOM_PEERS/);
  assert.match(rtc, /MAX_SIGNALS_PER_POLL/);
  assert.match(rtc, /z\.discriminatedUnion/);
});
