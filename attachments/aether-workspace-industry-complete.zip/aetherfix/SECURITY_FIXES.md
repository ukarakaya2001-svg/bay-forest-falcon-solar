# Security and correctness fixes

Applied in this revision:

- Fixed HTML escaping in the Aether syntax highlighter (`&`, `<`, `>`, `"`, `'`). This closes the code-editor XSS path caused by rendering highlighted source with `dangerouslySetInnerHTML`.
- Added regression coverage proving HTML-looking Aether source is rendered as escaped text rather than executable markup.
- Prevented generated entry-point targets (Go, C, C++, Rust, Swift, Java, C#, Haskell) from emitting a second `main` declaration when the Aether source already declares `main`.
- Stopped omitted Aether function return types from being silently mapped to an integer return type.
- Fixed top-level Java type declarations so they are not emitted as `static class` outside a containing class.
- Fixed Go generation so `fmt` is imported only when printing is actually used.
- Fixed Lua function block generation so `function main()` is not emitted as `function main() then`.
- Added regression tests for all of the above.

Validation:

- Aether regression suite: 17/17 passed.
- Existing project test suite: 187/195 passed; 8 pre-existing Grok PWA metadata fixture tests remain failing and are unrelated to these changes.
- Dependency vulnerability audit could not be completed because the environment could not reach registry.npmjs.org.

- Added a 1,000,000-character lexer/highlighter input ceiling to bound CPU/memory exposure from oversized editor input.
- Added response hardening headers to deployed PWA document/manifest responses (`nosniff`, strict referrer policy, restrictive permissions policy, COOP).
- Hardened the auth popup completion response with `no-store`, `nosniff`, `no-referrer`, COOP and a restrictive CSP; the popup token payload is still `<`-escaped before embedding.
- Added regression coverage for the oversized-source limit.

Additional validation in this revision:
- Aether suite: 18/18 passed.
- PWA plugin suite: 39/47 passed; the same 8 existing fixture failures concern the workspace `site.json` title/card expectations and are unrelated to the security changes.
- Full dependency audit remains unverified because package installation/registry access timed out in the isolated environment.
