/**
 * Bounded WebRTC signaling relay.
 * Only SDP/ICE rendezvous data crosses the server; application data remains P2P.
 */
import { z } from "zod";
import { getSql, type Sql } from "@/lib/db";
import type { PeerRow, RtcPollResponse, SignalRow } from "./p2p";

const ID = z.string().regex(/^[A-Za-z0-9_-]{1,64}$/);
const NAME = z.string().trim().max(64);
const MAX_SIGNAL_BYTES = 32_768;
const MAX_ROOM_PEERS = 32;
const MAX_SIGNALS_PER_POLL = 100;
const PEER_TTL_SECONDS = 30;
const SIGNAL_TTL_SECONDS = 60;

const signalSchema = z.object({
  op: z.literal("signal"),
  room: ID,
  from: ID,
  to: ID,
  kind: z.enum(["offer", "answer", "ice"]),
  payload: z.unknown().superRefine((value, ctx) => {
    try {
      const bytes = new TextEncoder().encode(JSON.stringify(value)).byteLength;
      if (bytes > MAX_SIGNAL_BYTES) {
        ctx.addIssue({ code: "custom", message: "payload too large" });
      }
    } catch {
      ctx.addIssue({ code: "custom", message: "payload is not serializable" });
    }
  }),
});
const leaveSchema = z.object({ op: z.literal("leave"), room: ID, peer: ID });
const postSchema = z.discriminatedUnion("op", [signalSchema, leaveSchema]);

const globalRef = globalThis as typeof globalThis & {
  __aetherRtcSchemaPromise__?: Promise<void>;
};

function ensureSchema(sql: Sql): Promise<void> {
  globalRef.__aetherRtcSchemaPromise__ ??= (async () => {
    await sql.query(`CREATE TABLE IF NOT EXISTS webrtc_peers (
      room TEXT NOT NULL,
      peer_id TEXT NOT NULL,
      name TEXT NOT NULL DEFAULT '',
      last_seen TIMESTAMPTZ NOT NULL DEFAULT now(),
      PRIMARY KEY (room, peer_id)
    )`);
    await sql.query(`CREATE TABLE IF NOT EXISTS webrtc_signals (
      id BIGSERIAL PRIMARY KEY,
      room TEXT NOT NULL,
      to_peer TEXT NOT NULL,
      from_peer TEXT NOT NULL,
      kind TEXT NOT NULL,
      payload JSONB NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )`);
    await sql.query(`CREATE INDEX IF NOT EXISTS webrtc_signals_inbox
      ON webrtc_signals (room, to_peer, id)`);
  })().catch((error) => {
    globalRef.__aetherRtcSchemaPromise__ = undefined;
    throw error;
  });
  return globalRef.__aetherRtcSchemaPromise__;
}

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
    },
  });
}

async function prune(sql: Sql): Promise<void> {
  await Promise.all([
    sql.query(`DELETE FROM webrtc_signals WHERE created_at < now() - make_interval(secs => $1)`, [SIGNAL_TTL_SECONDS]),
    sql.query(`DELETE FROM webrtc_peers WHERE last_seen < now() - make_interval(secs => $1)`, [PEER_TTL_SECONDS]),
  ]);
}

async function roster(sql: Sql, room: string): Promise<PeerRow[]> {
  const rows = await sql.query<{ peer_id: string; name: string }>(
    `SELECT peer_id, name FROM webrtc_peers
     WHERE room = $1 AND last_seen > now() - make_interval(secs => $2)
     ORDER BY peer_id LIMIT $3`,
    [room, PEER_TTL_SECONDS, MAX_ROOM_PEERS],
  );
  return rows.map((row) => ({ id: row.peer_id, name: row.name }));
}

async function touchPeer(sql: Sql, room: string, peer: string, name: string): Promise<void> {
  await sql.query(
    `INSERT INTO webrtc_peers (room, peer_id, name, last_seen)
     VALUES ($1, $2, $3, now())
     ON CONFLICT (room, peer_id)
     DO UPDATE SET last_seen = now(), name = EXCLUDED.name`,
    [room, peer, name],
  );
}

async function handleGet(url: URL): Promise<Response> {
  const parsed = z.object({
    room: ID,
    peer: ID,
    name: NAME.default(""),
    since: z.coerce.number().int().min(0).max(Number.MAX_SAFE_INTEGER).default(0),
  }).safeParse({
    room: url.searchParams.get("room"),
    peer: url.searchParams.get("peer"),
    name: url.searchParams.get("name") ?? "",
    since: url.searchParams.get("since") ?? 0,
  });
  if (!parsed.success) return json({ error: "invalid query" }, 400);

  const { room, peer, name, since } = parsed.data;
  const sql = await getSql();
  await ensureSchema(sql);
  if (since === 0 || Math.random() < 0.02) await prune(sql);

  const currentRoster = await roster(sql, room);
  if (!currentRoster.some((item) => item.id === peer) && currentRoster.length >= MAX_ROOM_PEERS) {
    return json({ error: "room is full" }, 409);
  }
  await touchPeer(sql, room, peer, name);

  const rows = await sql.query<{
    id: number;
    from_peer: string;
    kind: SignalRow["kind"];
    payload: unknown;
  }>(
    `SELECT id, from_peer, kind, payload FROM webrtc_signals
     WHERE room = $1 AND to_peer = $2 AND id > $3
     ORDER BY id LIMIT $4`,
    [room, peer, since, MAX_SIGNALS_PER_POLL],
  );

  const body: RtcPollResponse = {
    peers: await roster(sql, room),
    signals: rows.map((row) => ({ id: row.id, from: row.from_peer, kind: row.kind, payload: row.payload })),
  };
  return json(body);
}

async function handlePost(request: Request): Promise<Response> {
  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (Number.isFinite(contentLength) && contentLength > MAX_SIGNAL_BYTES + 4096) {
    return json({ error: "request too large" }, 413);
  }
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return json({ error: "invalid JSON" }, 400);
  }
  const parsed = postSchema.safeParse(body);
  if (!parsed.success) return json({ error: "invalid request" }, 400);

  const msg = parsed.data;
  const sql = await getSql();
  await ensureSchema(sql);

  if (msg.op === "signal") {
    if (msg.from === msg.to) return json({ error: "cannot signal yourself" }, 400);
    const peers = await roster(sql, msg.room);
    if (!peers.some((peer) => peer.id === msg.from) || !peers.some((peer) => peer.id === msg.to)) {
      return json({ error: "peer is not in room" }, 404);
    }
    await sql.query(
      `INSERT INTO webrtc_signals (room, to_peer, from_peer, kind, payload)
       VALUES ($1, $2, $3, $4, $5)`,
      [msg.room, msg.to, msg.from, msg.kind, JSON.stringify(msg.payload)],
    );
  } else {
    await sql.query(`DELETE FROM webrtc_peers WHERE room = $1 AND peer_id = $2`, [msg.room, msg.peer]);
    await sql.query(`DELETE FROM webrtc_signals WHERE room = $1 AND (to_peer = $2 OR from_peer = $2)`, [msg.room, msg.peer]);
  }
  return json({ ok: true });
}

export async function handleSignaling(request: Request): Promise<Response> {
  try {
    if (request.method === "POST") {
      const origin = request.headers.get("origin");
      if (origin) {
        const requestOrigin = new URL(request.url).origin;
        if (origin !== requestOrigin) return json({ error: "cross-origin request denied" }, 403);
      }
    }
    if (request.method === "GET") return await handleGet(new URL(request.url));
    if (request.method === "POST") return await handlePost(request);
    return json({ error: "method not allowed" }, 405);
  } catch (error) {
    console.error("[rtc] signaling error:", error instanceof Error ? error.message : "unknown error");
    return json({ error: "signaling failed" }, 500);
  }
}
