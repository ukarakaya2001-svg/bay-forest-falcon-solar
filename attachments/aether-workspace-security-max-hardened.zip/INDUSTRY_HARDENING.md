# Aether Production Hardening Baseline

This document records the production-oriented controls implemented in the
workspace. It is a baseline, not a security certification.

## Application security

- HTML output from the Aether syntax highlighter is entity-escaped before DOM insertion.
- OAuth providers are allowlisted server-side.
- OAuth callback/error destinations are restricted to same-origin paths.
- Popup messages require both the expected origin and the exact popup window source.
- Popup completion pages use `no-store`, `nosniff`, `no-referrer`, COOP and CSP.
- OAuth client secrets are runtime configuration only; no preview client secret is stored in source.
- WebRTC signaling validates identifiers, signal kinds and payload size.
- WebRTC rooms and inboxes have bounded peer/signal counts and TTL cleanup.
- Cross-origin WebRTC POST requests are rejected.
- Database access uses parameterized SQL.

## Language runtime

- Source input is capped at 1,000,000 characters.
- Interpreter execution is step-bounded.
- Function recursion is depth-bounded.
- List/map/struct/range allocations are bounded.
- Output lines and output bytes are bounded.
- Cyclic values are rendered safely.
- Generated entry points are target-specific.

## Engineering controls

- Locked dependencies (`package-lock.json`).
- `.env.example` documents runtime secrets without shipping their values.
- `.gitignore` excludes credentials and build artifacts.
- `SECURITY.md` defines private vulnerability reporting and release gates.
- CI runs dependency installation, verification, linting, typechecking and build.
- High-severity production dependency audit is a CI gate.
- Transpiler compiler smoke tests are available for installed toolchains.

## Verification performed in this environment

- Script/unit suite: **195/195 passed**.
- Aether + security suite: **26/26 passed**.
- Available compiler smoke targets: **9/9 passed** (JavaScript, Python, Ruby,
  Go, C, C++, Java, Kotlin, PHP).

The environment did not contain all 18 target-language toolchains, and package
installation from the npm registry timed out. Therefore a full dependency-backed
`typecheck`, `lint`, `build`, `npm audit`, and all-18 compiler verification must
still be executed in a networked CI environment before a production release.
