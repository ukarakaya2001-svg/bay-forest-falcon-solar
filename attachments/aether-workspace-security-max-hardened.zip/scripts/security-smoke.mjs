#!/usr/bin/env node
import assert from "node:assert/strict";
import { test } from "node:test";
import { readFileSync } from "node:fs";

const client = readFileSync(new URL("../src/lib/auth/client.ts", import.meta.url), "utf8");
const popup = readFileSync(new URL("../src/lib/auth/popup.server.ts", import.meta.url), "utf8");
const highlight = readFileSync(new URL("../src/lib/aether/highlight.ts", import.meta.url), "utf8");
const rtc = readFileSync(new URL("../src/lib/multiplayer/signaling.server.ts", import.meta.url), "utf8");
const embedder = readFileSync(new URL("../src/lib/preview-embedder-origin.ts", import.meta.url), "utf8");
const popupServer = readFileSync(new URL("../src/lib/auth/popup.server.ts", import.meta.url), "utf8");
const connectorServer = readFileSync(new URL("../src/lib/app-data/client.server.ts", import.meta.url), "utf8");

test("auth callbacks are normalized to same-origin paths", () => {
  assert.match(client, /safeCallbackPath/);
  assert.doesNotMatch(client, /window\.location\.href\s*=\s*callbackURL/);
});

test("popup provider is allowlisted and opener is authenticated", () => {
  assert.match(popup, /GROK_PROVIDERS\.some/);
  assert.match(popup, /script-src 'nonce-/);
  assert.doesNotMatch(popup, /script-src 'unsafe-inline'/);
  assert.match(client, /event\.source !== popup/);
});

test("highlighting does not directly trust raw HTML", () => {
  assert.match(highlight, /&amp;/);
  assert.match(highlight, /&lt;/);
  assert.match(highlight, /&gt;/);
});

test("RTC signaling has strict schema and bounded traffic", () => {
  assert.match(rtc, /MAX_SIGNAL_BYTES/);
  assert.match(rtc, /MAX_ROOM_PEERS/);
  assert.match(rtc, /MAX_SIGNALS_PER_POLL/);
  assert.match(rtc, /z\.discriminatedUnion/);
  assert.match(rtc, /x-aether-rtc-token/);
  assert.match(rtc, /randomBytes\(TOKEN_BYTES\)/);
  assert.match(rtc, /authenticatePeer/);
  assert.match(rtc, /readBoundedJson/);
  assert.match(rtc, /rate limit exceeded/);
  assert.match(rtc, /cross-site request denied/);
});


test("sandbox preview bridge never trusts an arbitrary framing origin", () => {
  assert.doesNotMatch(embedder, /isSandboxPreviewGuestHost\(guestHostname\)\s*\|\|/);
  assert.match(embedder, /isRemintPreviewPair\(guestHostname, url\.hostname\)/);
});

test("oauth popup validates the broker redirect destination", () => {
  assert.match(popupServer, /redirect\.protocol !== "https:"/);
  assert.match(popupServer, /redirect\.origin !== issuer\.origin/);
});


test("connector forwarding only permits trusted HTTPS gate hosts", () => {
  assert.match(connectorServer, /CONNECTORS_HOST_PROD/);
  assert.match(connectorServer, /CONNECTORS_HOST_STAGING/);
  assert.match(connectorServer, /url\.protocol !== "https:"/);
  assert.match(connectorServer, /trustedGateLoginUrl/);
});
